# Front-end assignment


## How to run this application
- Make sure you have an internet connection
- open the "index.html" in your browser.
- Everytime you refresh you get new pictures.